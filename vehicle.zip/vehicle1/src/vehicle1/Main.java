package vehicle1;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Master vehicle = new Master(2020,822,"white");
		System.out.println(vehicle.toString());
		vehicle.Masterout();
		
		bike b = new bike(2020,777,"black","Sports");
		System.out.println(b.toString());
		b.bikeout();

	}

}
