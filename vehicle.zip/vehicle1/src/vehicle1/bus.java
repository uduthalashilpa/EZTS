package vehicle1;

public class bus extends Master {
	private String Type;
	
	public bus(int model, int engine, String color, String type) {
		super (model, engine, color);
		Type = Type;
	}
	
	@Override
	public String toString() {
		return "bus [Type=" + Type + ", toString()=" + super.toString() + "]";
	}
	
	void busout() {
		super.Masterout();
		System.out.println("Type = "+Type);
	}
}

