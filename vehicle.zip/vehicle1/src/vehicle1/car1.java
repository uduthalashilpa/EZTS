package vehicle1;

public class car1 extends Master {
	private String Type;
	
	public car1(int model, int engine, String color, String type) {
		super(model, engine, color);
		Type = Type;
	}
	
	@Override
	public String toString() {
		return"car1 [Type=" + Type + ", toString()=" + super.toString() + "]";
	}
	
	void car1out() {
		super.Masterout();
		System.out.println("Type = "+Type);
	}

}
